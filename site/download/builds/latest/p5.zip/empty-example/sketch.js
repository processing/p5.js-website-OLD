function setup() {
  // put setup code here
  createCanvas(600, 400);
}

function draw() {
  // put drawing code here
}