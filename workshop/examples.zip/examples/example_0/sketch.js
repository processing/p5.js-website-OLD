function setup() {

  createGraphics(600, 400);

}

function draw() {

  // background
  background(42, 169, 217);

  // ellipse
  fill(242, 228, 21);
  ellipse(100,100,100,100);

  //rectangle
  fill(162,217, 39);
  rect(300,100,150,150);

}